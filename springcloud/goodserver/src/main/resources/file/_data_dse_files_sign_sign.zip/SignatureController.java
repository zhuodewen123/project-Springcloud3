package com.csg.dse.web.controller.aksk;
import com.csg.dse.vo.JsonResult;
import com.csg.dse.vo.aksk.Signature;
import com.csg.dse.web.signature.exception.BceClientException;
import com.csg.dse.web.signature.http.Headers;
import com.csg.dse.web.signature.util.DateUtils;
import com.csg.dse.web.signature.util.HttpUtils;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.apache.commons.codec.binary.Hex;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: wangqs
 * @Date: 2019/9/3 19:51
 * @Description: 生成验证字符串
 */

@RestController
@RequestMapping("/dataservice")
public class SignatureController {

    private static final String BCE_AUTH_VERSION = "data-service-auth-v1";
    private static final String DEFAULT_ENCODING = "UTF-8";
    private static final Charset UTF8 = Charset.forName(DEFAULT_ENCODING);
    private static BitSet URI_UNRESERVED_CHARACTERS = new BitSet();
    private static String[] PERCENT_ENCODED_STRINGS = new String[256];
    private static final Joiner JOINER_STRING = Joiner.on('&');
    private static final Joiner HEADER_JOINER = Joiner.on('\n');

    /**
     * 使用BCE签名协议签名的默认头。
     */
    private static final Set<String> DEFAULT_HEADERS_TOSIGN = Sets.newHashSet();

    @PostMapping("/createSignature")
    public JsonResult testIntercept(@RequestBody Signature signature)
    {

        Map<String,String> result = new HashMap<>(8);
        System.out.println(signature);
        Map<String, Object> requestParamMap = signature.getRequestParamMap();
        System.out.println(requestParamMap);
        String resultStr = createSign(signature);
        result.put("result",resultStr);
        System.out.println(result);
        return JsonResult.succ().data(result);
    }
    public String createSign(Signature requestParam)
    {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        //创建httppost对象
        String result =  "这是默认返回值，接口调用失败";  ;
        try {

            String url =requestParam.getUrl();
            String json ="{\"s\":\"ssss\"}";
            HttpPost httpPost = new HttpPost(url);
            //第三步：给httpPost设置JSON格式的参数
            StringEntity requestEntity = new StringEntity(json,"utf-8");
            requestEntity.setContentEncoding("UTF-8");
            httpPost.setHeader("Content-type", "application/json");

            String ak = requestParam.getAk();
            String sk = requestParam.getSk();
            String timestamp = "";
            String expirationPeriodInSeconds = "1800";
            /**
             * param：为验证字符串
             * sjfw-auth-v1：验证头部信息
             * ak：ak
             * timestamp:签名生效UTC时间，格式为yyyy-mm-ddThh:mm:ssZ
             * expirationPeriodInSeconds:签名有效期限
             * signedHeaders:签名算法中涉及到的HTTP头域列表,HTTP头域名字一律要求小写且头域名字之间用分号（;）分隔，如host;range;x-sjfw-date。列表按照字典序排列。当signedHeaders为空时表示取默认值。
             * Signature:签名摘要。
             */
            String param = "sjfw-auth-v1/{ak}/{timestamp}/{expirationPeriodInSeconds}/{signedHeaders}/{Signature}";

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date time = new Date();

            String authString = getAuthString(ak, time, expirationPeriodInSeconds, sk);
            System.out.println("authString:"+authString);
            // 签名Key
            String signingKey = sha256Hexxx(sk, authString);
            String canonicalUri = getCanonicalUriPath(url);
            System.out.println("canonicalUri:"+canonicalUri);
            //请求参数处理
            Map<String, String> parameterMap = new HashMap<String, String>(8);

            //Map<String, String[]> parameterMapArr = new HashMap<>();

            for(Map.Entry<String, Object> map:requestParam.getRequestParamMap().entrySet())
            {
                String key = map.getKey();
               // String[] value = map.getValue();
                //for (String string : value) {
                    if(!"signature".equals(key))
                    {
                        parameterMap.put(map.getKey(), map.getValue().toString());
                    }
                //}
            }
            System.out.println("请求参数："+parameterMap);


            String canonicalQueryString = HttpUtils.getCanonicalQueryString(parameterMap, true);

            System.out.println("canonicalQueryString:"+canonicalQueryString);
            //请求头部参数处理
            Map<String, String> headerParameters = Maps.newHashMap();

            Set<String> headers = new HashSet<>();
            headers.add("Authorization");
            SortedMap<String, String> headersToSign = getHeadersToSign(headerParameters, headers);

            System.out.println("headersToSign:"+headersToSign);
            String canonicalHeaders = getCanonicalHeaders(headersToSign);
            System.out.println("canonicalHeaders:"+canonicalHeaders);
            // 标准规范请求
            String canonicalRequest = "POST" + "\n" + canonicalUri + "\n" + canonicalQueryString + "\n"
                    + canonicalHeaders;
            System.out.println("canonicalRequest:"+canonicalRequest);
            String signature = sha256Hexxx(signingKey, canonicalRequest);

            System.out.println("signature"+signature);
            param = SignatureController.BCE_AUTH_VERSION + "/" + ak + "/"
                    + sdf.format(time) + "/" + expirationPeriodInSeconds +"/"+ signature;
            System.out.println("=========="+param);
            httpPost.setHeader("Authorization",param);
            result = param;

            //httpPost.setEntity(requestEntity);
            //第四步：发送HttpPost请求，获取返回值
            //result = httpClient.execute(httpPost,responseHandler);
            //System.out.println(result);
        }catch (Exception e)
        {

        }

        return result;
    }

    /**
     * 验证字符串前缀
     * @param ak：ak
     * @param time：签名生效UTC时间
     * @param expirationPeriodInSeconds：签名有效期限
     * @param sk：sk
     * @return
     */
    public static String getAuthString(String ak, Date time,String expirationPeriodInSeconds,String sk)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 验证字符串前缀
        String authString = SignatureController.BCE_AUTH_VERSION + "/" + ak + "/"
                + DateUtils.formatAlternateIso8601Date(time) + "/" + expirationPeriodInSeconds;

        System.out.println("time:"+DateUtils.formatAlternateIso8601Date(time));
        return authString;
    }
    /**
     *
     * @Title: sha256Hex：sha256Hex算法
     * @param @param signingKey：签名Key
     * @param @param stringToSign :标题字符串
     * @param @return String 返回类型：字符串
     */
    private static String sha256Hexxx(String signingKey, String stringToSign) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(signingKey.getBytes(UTF8), "HmacSHA256"));
            return new String(Hex.encodeHex(mac.doFinal(stringToSign.getBytes(UTF8))));
        } catch (Exception e) {
            throw new BceClientException("Fail to generate the signature", e);
        }
    }

    /**
     * uri路径 是对URL中的绝对路径进行编码，要求绝对路径必须以“/”开头，不以“/”开头的需要补充上，空路径为“/”
     * @param path 路径
     * @return 路径
     */
    private static String getCanonicalUriPath(String path) {
        String a = "/";
        if (path == null) {

            return "/";
        } else if (path.startsWith(a)) {
            return HttpUtils.normalizePath(path);
        } else {
            return "/" + HttpUtils.normalizePath(path);
        }
    }

    /**
     *  转为数组
     * @param value
     * @return
     */
    public static String normalize(String value) {
        try {
            StringBuilder builder = new StringBuilder();
            for (byte b : value.getBytes(DEFAULT_ENCODING)) {
                if (URI_UNRESERVED_CHARACTERS.get(b & 0xFF)) {
                    builder.append((char) b);
                } else {
                    builder.append(PERCENT_ENCODED_STRINGS[b & 0xFF]);
                }
            }
            return builder.toString();
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 请求头处理
     * @param headers
     * @param headersToSign
     * @return
     */
    private static SortedMap<String, String> getHeadersToSign(Map<String, String> headers, Set<String> headersToSign) {
        SortedMap<String, String> ret = Maps.newTreeMap();
        if (headersToSign != null) {
            Set<String> tempSet = Sets.newHashSet();
            for (String header : headersToSign) {
                tempSet.add(header.trim().toLowerCase());
            }
            headersToSign = tempSet;
        }
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            String key = entry.getKey();
            if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                boolean bool = (headersToSign == null && isDefaultHeaderToSign(key)) || (headersToSign != null
                        && headersToSign.contains(key.toLowerCase()) && !Headers.AUTHORIZATION.equalsIgnoreCase(key));
                if (bool) {
                    ret.put(key, entry.getValue());
                }
            }
        }
        return ret;
    }

    private static boolean isDefaultHeaderToSign(String header) {
        header = header.trim().toLowerCase();
        return header.startsWith(Headers.BCE_PREFIX) || DEFAULT_HEADERS_TOSIGN.contains(header);
    }
    /**
     * 根据签名格式格式化请求中的标题 @Title: getCanonicalHeaders @Description:
     * String 返回类型 @throws
     */
    private static String getCanonicalHeaders(SortedMap<String, String> headers) {
        if (headers.isEmpty()) {
            return "";
        }

        List<String> headerStrings = Lists.newArrayList();
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            String key = entry.getKey();
            if (key == null) {
                continue;
            }
            String value = entry.getValue();
            if (value == null) {
                value = "";
            }
            headerStrings.add(HttpUtils.normalize(key.trim().toLowerCase()) + ':' + HttpUtils.normalize(value.trim()));
        }
        Collections.sort(headerStrings);
        return HEADER_JOINER.join(headerStrings);
    }
}
